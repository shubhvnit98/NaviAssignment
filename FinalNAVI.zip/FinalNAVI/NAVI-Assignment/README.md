# TheLedgerCo


Sample input
Please Enter the full File Path. Example ->/home/akshanshohm/eclipse-workspace/TheLedgerCo/src/test.txt
/home/akshanshohm/eclipse-workspace/TheLedgerCo/src/test2.txt


Output for same are

text
MBI Dale 1000 40
MBI Dale 3250 22



text1

IDIDI Dale 1000 55
IDIDI Dale 8000 20
MBI Harry 1044 12
MBI Harry 0 24



text2 

IDIDI Dale 1326 9
IDIDI Dale 3652 4
UON Shelly 15856 3
MBI Harry 9044 10
