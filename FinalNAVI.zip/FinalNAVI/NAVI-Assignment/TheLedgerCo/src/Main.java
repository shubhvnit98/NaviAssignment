import java.util.Scanner;

import driver.FileProcessor;

public class Main {

	public static void main(String[] args) {

		FileProcessor FP = new FileProcessor();

		if (args.length == 1)
		{
			FP.parseFileInput(args[0]);
		}
		else
		{
			Scanner sc = new Scanner(System.in);

			System.out.println("Please Enter the full File Path.");

			FP.parseFileInput(sc.nextLine());
		}

	}

}
